package aplikacija.bralnik;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceFragment;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.CheckBox;
import android.widget.Toast;

/**
 * Created by Žiga on 16.12.2017.
 */

public class SwitchNastavitve extends PreferenceFragment {
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.zvok);
    }


    @Override
    public void onStart(){
        super.onStart();

    }

    @Override
    public void onResume(){
        super.onResume();
        // za switch
        android.preference.SwitchPreference preferenceVib =(android.preference.SwitchPreference) findPreference("switch1");
        preferenceVib.setSummaryOff("Izključeno");
        preferenceVib.setSummaryOn("Vključeno");
        // za switch
        android.preference.SwitchPreference preferenceSpor = (android.preference.SwitchPreference) findPreference("switch2");
        preferenceSpor.setSummaryOff("Izključeno");
        preferenceSpor.setSummaryOn("Vključeno");
        // za checkbox
        //android.preference.CheckBoxPreference preferenceCheck =(android.preference.CheckBoxPreference) findPreference("mute");
        //preferenceCheck.setSummaryOff("Izključeno");
        //preferenceCheck.setSummaryOn("Vključeno");

        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getActivity());
        boolean preveri = sharedPreferences.getBoolean("switch1",false);
        boolean preveri2 = sharedPreferences.getBoolean("switch2",false);
        //boolean preveri3 = sharedPreferences.getBoolean("mute",false);
        if(preveri == true){
            Toast.makeText(getActivity(),"Vibriranje je vključeno ", Toast.LENGTH_SHORT).show();
        }
        else{
            Toast.makeText(getActivity(),"Vibriranje je izključeno ", Toast.LENGTH_SHORT).show();
        }
        if(preveri2 == true){
            Toast.makeText(getActivity(),"Obveščanje je vključeno ", Toast.LENGTH_SHORT).show();
        }
        else{
            Toast.makeText(getActivity(),"Obveščanje je izključeno ", Toast.LENGTH_SHORT).show();
        }
        /*if(preveri3 == true){
            Toast.makeText(getActivity(),"Zvok je vključen ", Toast.LENGTH_SHORT).show();
        }
        else{
            Toast.makeText(getActivity(),"Zvok je izključen ", Toast.LENGTH_SHORT).show();
        }*/
    }
    /*
    public void Utisaj(View item){
        if(((CheckBox) item).isChecked()){
            Toast.makeText(getActivity(),"Omogočeno", Toast.LENGTH_LONG).show();
        }

    }
    */
}
