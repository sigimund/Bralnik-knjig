package aplikacija.bralnik;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.CheckBoxPreference;
import android.preference.Preference;
import android.preference.PreferenceFragment;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.CheckBox;
import android.widget.Toast;
import android.preference.Preference.OnPreferenceClickListener;

/**
 * Created by Žiga on 16.12.2017.
 */

public class CheckboxNastavitve extends PreferenceFragment {
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.zvok);

        /*
        CheckBoxPreference skatla = (CheckBoxPreference) findPreference("mute"); // ustvarimo checkbox
        Boolean checkBoxState = skatla.isChecked(); // tukaj preverimo če je označen ali ne

        if(checkBoxState == true){
            Toast.makeText(getActivity(),"Omogočeno", Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(getActivity(), "Onemogočeno", Toast.LENGTH_SHORT).show();
        }
        */
        final CheckBoxPreference skatla = (CheckBoxPreference) findPreference("mute"); // ustvarimo checkbox
        skatla.setOnPreferenceClickListener(new OnPreferenceClickListener() {
            public boolean onPreferenceClick(Preference preference) {
                skatla.setSelectable(true);
                Toast.makeText(getActivity(), "Omogočeno", Toast.LENGTH_SHORT).show();
                return true;
            }
        });

    }

    /*
    @Override
    public void onStart(){
        super.onStart();
        /*
        CheckBoxPreference skatla = (CheckBoxPreference) findPreference("mute"); // ustvarimo checkbox
        Boolean checkBoxState = skatla.isChecked(); // tukaj preverimo če je označen ali ne

        if(checkBoxState == true){
            Toast.makeText(getActivity(),"Omogočeno", Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(getActivity(),"Onemogočeno", Toast.LENGTH_SHORT).show();
        }
    }
    */


    @Override
    public void onResume(){
        super.onResume();
        android.preference.CheckBoxPreference preferenceCheck =(android.preference.CheckBoxPreference) findPreference("mute");
        preferenceCheck.setSummaryOff("Izključeno");
        preferenceCheck.setSummaryOn("Vključeno");

        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getActivity());
        boolean preveri = sharedPreferences.getBoolean("mute",false);
        if(preveri == true){
            Toast.makeText(getActivity(),"Zvok je vključen ", Toast.LENGTH_SHORT).show();
        }
        else{
            Toast.makeText(getActivity(),"Zvok je izključen ", Toast.LENGTH_SHORT).show();
        }
    }


    public void Muted(View item){
        CheckBox skatla = (CheckBox)item;

        if(((CheckBox) item).isChecked()){
            Toast.makeText(getActivity(),"Omogočeno", Toast.LENGTH_LONG).show();
        }

    }

}
