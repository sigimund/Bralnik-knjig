package aplikacija.bralnik;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Window;

public class oNas extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_INDETERMINATE_PROGRESS);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_o_nas);
    }
}
