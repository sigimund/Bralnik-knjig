package aplikacija.bralnik;

import android.app.Fragment;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.preference.Preference;
import android.preference.PreferenceFragment;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.Window;
import android.widget.CheckBox;
import android.widget.CheckedTextView;
import android.widget.Toast;

/**
 * Created by Žiga on 3.12.2017.
 */

public class zaZvok extends AppCompatActivity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_INDETERMINATE_PROGRESS);
        super.onCreate(savedInstanceState);

        setContentView(R.layout.nastavi);

        Fragment fragment = new zaZvok.ZvokZaslon();
        FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
        if (savedInstanceState == null) {
            // ko ustvarimo prvič
            fragmentTransaction.add(R.id.nastaviStran, fragment, "zvok_fragment");
            fragmentTransaction.commit();
        } else {
            fragment = getFragmentManager().findFragmentByTag("zvok_fragment");
        }

        // tukaj kličemo naše razrede v katerih imamo nastavitve za različne elemente
        getFragmentManager().beginTransaction().replace(R.id.nastaviStran,new SwitchNastavitve()).commit();
        getFragmentManager().beginTransaction().replace(R.id.nastaviStran,new CheckboxNastavitve()).commit();
    }

    @Override
    public void onStart(){
        super.onStart();
        /*
        CheckBox simpleCheckBox = (CheckBox) findViewById(R.id.muted); // ustvarimo checkbox
        Boolean checkBoxState = simpleCheckBox.isChecked(); // tukaj preverimo če je označen ali ne

        if(checkBoxState == true){
            Toast.makeText(this,"Omogočeno", Toast.LENGTH_LONG).show();
        }
        else {
            Toast.makeText(this,"Onemogočeno", Toast.LENGTH_LONG).show();
        }*/
    }

    public static class ZvokZaslon extends PreferenceFragment {
        @Override
        public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            addPreferencesFromResource(R.xml.zvok);
        }

    }

    /*
    public void Muted(View view) {
        boolean preveri = ((CheckBox) view).isChecked();

        if(preveri == true){
            Toast.makeText(this,"Omogočeno", Toast.LENGTH_SHORT).show();
        }
        else{
            Toast.makeText(this,"Onemogočeno", Toast.LENGTH_SHORT).show();
        }
    }
    */

}
