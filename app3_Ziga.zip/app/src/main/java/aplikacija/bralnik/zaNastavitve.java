package aplikacija.bralnik;

import android.app.Fragment;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.preference.PreferenceFragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.Toolbar;

/**
 * Created by Žiga on 25.11.2017.
 */

public class zaNastavitve extends AppCompatActivity {


}
