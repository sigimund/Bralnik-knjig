package aplikacija.bralnik;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class oNas extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_o_nas);
    }
}
