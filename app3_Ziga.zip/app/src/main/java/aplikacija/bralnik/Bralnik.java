package aplikacija.bralnik;

import android.app.Fragment;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.preference.PreferenceFragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.Toolbar;

public class Bralnik extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bralnik);

        setTitle(null);

        Toolbar meniToolbar = (Toolbar) findViewById(R.id.ZaMeni);
        setSupportActionBar(meniToolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);


        // ZA NASTAVITVE
        Fragment fragment = new NastavitveZaslon();
        FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
        if (savedInstanceState == null) {
            fragmentTransaction.add(R.id.action_setting, fragment, "nastavitve_fragment"); // nevem če dela
            fragmentTransaction.commit();
        } else {
            fragment = getFragmentManager().findFragmentByTag("nastavitve_fragment");
        }
    }

    private void setSupportActionBar(Toolbar a) {
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater aa = getMenuInflater();
        aa.inflate(R.menu.meni, menu);
        return true;
    }

    public void Pokazi_Nastavitve(MenuItem item) {

        Intent odpri = new Intent(this, zaNastavitve.class);
        startActivity(odpri);

    }

    public void Pokazi_oNas(MenuItem item) {

        Intent onas = new Intent(this, oNas.class);
        startActivity(onas);

    }

    // ZA NASTAVITVE
    public static class NastavitveZaslon extends PreferenceFragment {
        @Override
        public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            addPreferencesFromResource(R.xml.nastavitve);
        }

    }


}
