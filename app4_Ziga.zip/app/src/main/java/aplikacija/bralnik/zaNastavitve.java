package aplikacija.bralnik;

import android.app.Fragment;
import android.app.FragmentTransaction;
import android.preference.Preference;
import android.preference.PreferenceFragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Window;

/**
 * Created by Žiga on 25.11.2017.
 */

public class zaNastavitve extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_INDETERMINATE_PROGRESS);
        super.onCreate(savedInstanceState);

        setContentView(R.layout.nastavi);

        // ZA NASTAVITVE
        Fragment fragment = new zaNastavitve.NastavitveZaslon();
        FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
        if (savedInstanceState == null) {
            // ko ustvarimo prvič
            fragmentTransaction.add(R.id.nastaviStran, fragment, "nastavitve_fragment");
            fragmentTransaction.commit();
        } else {
            fragment = getFragmentManager().findFragmentByTag("nastavitve_fragment");
        }

    }

    // ZA NASTAVITVE
    public static class NastavitveZaslon extends PreferenceFragment {
        @Override
        public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            addPreferencesFromResource(R.xml.nastavitve);
        }

    }
}
