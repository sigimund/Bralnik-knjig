package aplikacija.bralnik;

import android.app.Fragment;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.preference.PreferenceFragment;
import android.support.v7.app.AppCompatActivity;
import android.view.Window;

/**
 * Created by Žiga on 3.12.2017.
 */

public class zaZvok extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_INDETERMINATE_PROGRESS);
        super.onCreate(savedInstanceState);

        setContentView(R.layout.nastavi);


        Fragment fragment = new zaZvok.ZvokZaslon();
        FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
        if (savedInstanceState == null) {
            // ko ustvarimo prvič
            fragmentTransaction.add(R.id.nastaviStran, fragment, "zvok_fragment");
            fragmentTransaction.commit();
        } else {
            fragment = getFragmentManager().findFragmentByTag("zvok_fragment");
        }

    }
    public static class ZvokZaslon extends PreferenceFragment {
        @Override
        public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            addPreferencesFromResource(R.xml.zvok);
        }

    }
}
