package aplikacija.bralnik;

import android.app.AlertDialog;
import android.app.Fragment;
import android.app.FragmentTransaction;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Environment;
import android.preference.CheckBoxPreference;
import android.preference.ListPreference;
import android.preference.Preference;
import android.preference.PreferenceFragment;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.Window;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.Toast;

import java.io.File;
import java.lang.reflect.Array;

/**
 * Created by Žiga on 3.12.2017.
 */

public class zaShrambo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_INDETERMINATE_PROGRESS);
        super.onCreate(savedInstanceState);

        setContentView(R.layout.nastavi); // nastavi je activity stran v katero damo notri naš xml file pogled


        Fragment fragment = new zaShrambo.ShrambaZaslon();
        FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
        if (savedInstanceState == null) {
            // ko ustvarimo prvič
            fragmentTransaction.add(R.id.nastaviStran, fragment, "shramba_fragment");
            fragmentTransaction.commit();
        } else {
            fragment = getFragmentManager().findFragmentByTag("shramba_fragment");
        }



    }

    public static class ShrambaZaslon extends PreferenceFragment {
        @Override
        public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            addPreferencesFromResource(R.xml.pomnilnik);

            int stevilo = 0;
            int stevec = 0;

            // ZA CHECKBOX -----------------------------

            final CheckBoxPreference BrisiCheckbox = (CheckBoxPreference) findPreference("EraseCheck"); // tukaj naredimo novi
            // checkbox element s katerim dostopamo
            // do našega checkbox elementa z id BrisiCheck

            SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getActivity());
            final boolean preveri = sharedPreferences.getBoolean("EraseCheck",false);

            BrisiCheckbox.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
            @Override
            public boolean onPreferenceClick(Preference preference) {
                BrisiCheckbox.setSelectable(true);
                //if(preveri == true){
                //
                //}
                AlertDialog.Builder gradnik = new AlertDialog.Builder(getActivity()); // ustvarimo alertDialog gradnik
                // v katerem dodamo notri naša sporočila in aktivnosti
                gradnik.setMessage("Ali želite izbrisati vse knjige iz baze?").
                        setPositiveButton("Da", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                // TUKAJ NOTRI IZVEDEMO BRISANJE

                                ListPreference noviListPreference = (ListPreference) findPreference("izbris");
                                noviListPreference.setEntries(new String[]{""});
                                noviListPreference.setEntryValues(new String[]{"0"});
                                noviListPreference.setDialogMessage("Trenutno ni knjige za brisanje");

                                // Na koncu brisanja še ponastavimo checkbox element za false

                                BrisiCheckbox.setChecked(false);
                            }
                        }).setNegativeButton("Prekliči", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        // če uporabnik pritisne Prekliči se nič ne izvede
                        BrisiCheckbox.setChecked(false);
                    }
                });

                AlertDialog opozorilo = gradnik.create(); // naredimo AlertDialog element v katerem bomo imeli naš gradnik
                opozorilo.show(); // prikažemo gradnik ob ustreznem dogodku
                return true;
            }
        });


            // ODSTRANI DOLOČENO KNJIGO
            /*
            Preference.OnPreferenceChangeListener listener = new Preference.OnPreferenceChangeListener() {
                @Override
                public boolean onPreferenceChange(Preference preference, Object objekt) { // objekt je vrednost katero uporabnik izberemo
                    return false;
                }
            };
            */
            ListPreference OdsKnjigo = (ListPreference) findPreference("izbris");
            //OdsKnjigo.setOnPreferenceChangeListener(listener);

            OdsKnjigo.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
                @Override
                public boolean onPreferenceClick(Preference preference) {

                    AlertDialog.Builder gradnik = new AlertDialog.Builder(getActivity());

                    //OdsKnjigo.getValue();

                    ListPreference noviListPreference = (ListPreference) findPreference("izbris");

                    if(noviListPreference.getValue() != "0"){
                        noviListPreference.setValue("0"); // "izbrišemo knjigo"
                    }

                    CharSequence PridobiText = noviListPreference.getEntry();

                    Toast.makeText(getActivity(),"Izbrisali ste knjigo " + PridobiText, Toast.LENGTH_SHORT).show();

                    return true;
                }
            });


            // ZA TRENUTNO ŠTEVILO KNJIG

            ListPreference LPreference = (ListPreference) findPreference("izbris");
            stevilo = LPreference.getEntries().length;

            Preference StKnjig = (Preference) findPreference("prikaz_knjig");
            for(int i = 0; i < stevilo; i++){
                if(LPreference.getValue() != "0"){
                    stevec++;
                }
            }
            StKnjig.setSummary("Trenutno število knjig je : " + stevec);

        }
    }

    public void IzbrisiVse(String dir) { // parameter dir vsebuje naslov naše datoteke s knjigam
        File myDir = new File(Environment.getExternalStorageDirectory() + "/" + dir);
        if (myDir.isDirectory()) {
            String[] poljeDat = myDir.list();
            for (int i = 0; i < poljeDat.length; i++) {
                new File(myDir, poljeDat[i]).delete(); // izbrišemo vsako knjigo v naši datoteki
            }
        }
    }

    public void IzbrisiKnjigo(String dir, String name){ // parameter dir vsebuje naslov naše datoteke s knjigam,
        // name pa ime naše datoteke
        File myDir = new File(Environment.getExternalStorageDirectory() + "/" + dir);
        File dat = new File(myDir,name);
        dat.delete(); // izbrišemo datoteko
    }

    public int StKnjig(String dir){ // parameter dir vsebuje naslov naše datoteke s knjigam
        int stevec = 0;
        File myDir = new File(Environment.getExternalStorageDirectory() + "/" + dir);
        if (myDir.isDirectory()) {
            String[] poljeDat = myDir.list();
            for (int i = 0; i < poljeDat.length; i++) {
                stevec++; // štejemo naše knjige
            }
        }
        return stevec; // vrnemo števec
    }

}
