package aplikacija.bralnik;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.Window;
import android.support.v7.widget.Toolbar;

public class Bralnik extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        requestWindowFeature(Window.FEATURE_INDETERMINATE_PROGRESS);
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_bralnik);

        setTitle(null);

        Toolbar meniToolbar = findViewById(R.id.ZaMeni);
        setSupportActionBar(meniToolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater aa = getMenuInflater();
        aa.inflate(R.menu.meni, menu);
        return true;
    }

    public void Pokazi_Nastavitve(MenuItem item) {

        //Intent odpri = new Intent(this, zaNastavitve.class);
        Intent odpri = new Intent(this, nastavitveActivity.class);
        startActivity(odpri);
    }

    public void Pokazi_oNas(MenuItem item) {

        Intent onas = new Intent(this, oNas.class);
        startActivity(onas);

    }

    // Pred izhodom iz aplikacije se pojavi okno v katerem uporabnik potrdi če želi zapustiti stran
    @Override
    public void onBackPressed() {
        AlertDialog.Builder gradnik = new AlertDialog.Builder(this);
        gradnik.setMessage("Ali ste želiti zapustiti aplikacijo?")
                .setCancelable(false)
                .setPositiveButton("Da", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        Bralnik.this.finish(); // "ugasnemo" aplikacijo
                    }
                })
                .setNegativeButton("Prekliči", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        AlertDialog alert = gradnik.create();
        alert.show();

    }

}
