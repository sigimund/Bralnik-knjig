package aplikacija.bralnik;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;

/**
 * Created by Žiga on 3.12.2017.
 */

public class nastavitveActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_INDETERMINATE_PROGRESS);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.nastavitve_activity);
    }

    public void Pomnilniknastavitve(View view) {
        Intent odpriPomnilnik = new Intent(this, zaShrambo.class);
        startActivity(odpriPomnilnik);
    }

    public void SoundNastavitve(View view){
        Intent odpriZvok = new Intent(this, zaZvok.class);
        startActivity(odpriZvok);
    }

    public void PogledNastavitve(View view){
        Intent odpriPogled = new Intent(this, zaPogled.class);
        startActivity(odpriPogled);
    }

    public void JezikNastavitve(View view){
        Intent odpriJezik = new Intent(this, zaJezik.class);
        startActivity(odpriJezik);
    }

    public void PomocNastavitve(View view){
        Intent odpriPomoc = new Intent(this, zaPomoc.class);
        startActivity(odpriPomoc);
    }
}
