package aplikacija.bralnik;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.CheckBoxPreference;
import android.preference.Preference;
import android.preference.PreferenceFragment;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.CheckBox;
import android.widget.Toast;
import android.preference.Preference.OnPreferenceClickListener;

/**
 * Created by Žiga on 16.12.2017.
 */

public class CheckboxNastavitve extends PreferenceFragment {
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.zvok);

        final CheckBoxPreference skatla = (CheckBoxPreference) findPreference("mute"); // ustvarimo checkbox
        skatla.setOnPreferenceClickListener(new OnPreferenceClickListener() {
            @Override
            public boolean onPreferenceClick(Preference preference) {
                skatla.setSelectable(true);
                Toast.makeText(getActivity(), "Omogočeno", Toast.LENGTH_SHORT).show();
                return true;
            }
        });

    }

    @Override
    public void onResume(){
        super.onResume();
        android.preference.CheckBoxPreference preferenceCheck =(android.preference.CheckBoxPreference) findPreference("mute");
        preferenceCheck.setSummaryOff("Izključeno");
        preferenceCheck.setSummaryOn("Vključeno");

        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getActivity());
        boolean preveri = sharedPreferences.getBoolean("mute",false);
        if(preveri == true){
            Toast.makeText(getActivity(),"Zvok je vključen ", Toast.LENGTH_SHORT).show();
        }
        else{
            Toast.makeText(getActivity(),"Zvok je izključen ", Toast.LENGTH_SHORT).show();
        }
    }



}
