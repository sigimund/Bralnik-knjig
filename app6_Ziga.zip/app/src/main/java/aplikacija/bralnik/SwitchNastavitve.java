package aplikacija.bralnik;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.preference.CheckBoxPreference;
import android.preference.ListPreference;
import android.preference.Preference;
import android.preference.PreferenceFragment;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.widget.Toast;

/**
 * Created by Žiga on 16.12.2017.
 */

public class SwitchNastavitve extends PreferenceFragment {
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.zvok);

        final CheckBoxPreference CP = (CheckBoxPreference) findPreference("mute");

        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getActivity());
        final boolean preveri = sharedPreferences.getBoolean("mute",false);

        if(preveri){
            CP.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
                @Override
                public boolean onPreferenceChange(Preference preference, Object o) {

                    AlertDialog.Builder gradnik = new AlertDialog.Builder(getActivity()); // ustvarimo alertDialog gradnik
                    // v katerem dodamo notri naša sporočila in aktivnosti
                    gradnik.setMessage("Ali želite vključiti zvok?").
                            setPositiveButton("Da", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {

                                    //unmute audio
                                    //MediaPlayer mp = MediaPlayer.create(context, R.raw.sound_file_1);
                                    //mp.start();

                                    //mp.setvolume(0,1);
                                }
                            }).setNegativeButton("Prekliči", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            // če uporabnik pritisne Prekliči se nič ne izvede
                            CP.setChecked(false);
                        }
                    });

                    AlertDialog opozorilo = gradnik.create(); // naredimo AlertDialog element v katerem bomo imeli naš gradnik
                    opozorilo.show(); // prikažemo gradnik ob ustreznem dogodku
                    return true;
                }
            });
        }else{
            CP.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
                @Override
                public boolean onPreferenceChange(Preference preference, Object o) {

                    AlertDialog.Builder gradnik = new AlertDialog.Builder(getActivity()); // ustvarimo alertDialog gradnik
                    // v katerem dodamo notri naša sporočila in aktivnosti
                    gradnik.setMessage("Ali želite izključiti zvok?").
                            setPositiveButton("Da", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {

                                    //mute audio
                                    //MediaPlayer mp = MediaPlayer.create(context, R.raw.sound_file_1);
                                    //mp.start();

                                    //mp.setvolume(0,0);

                                }
                            }).setNegativeButton("Prekliči", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            // če uporabnik pritisne Prekliči se nič ne izvede
                            CP.setChecked(false);
                        }
                    });

                    AlertDialog opozorilo = gradnik.create(); // naredimo AlertDialog element v katerem bomo imeli naš gradnik
                    opozorilo.show(); // prikažemo gradnik ob ustreznem dogodku
                    return true;
                }
            });
        }

    }

    @Override
    public void onResume(){
        super.onResume();
        // za switch
        android.preference.SwitchPreference preferenceVib =(android.preference.SwitchPreference) findPreference("switch1");
        preferenceVib.setSummaryOff("Izključeno");
        preferenceVib.setSummaryOn("Vključeno");
        // za switch
        android.preference.SwitchPreference preferenceSpor = (android.preference.SwitchPreference) findPreference("switch2");
        preferenceSpor.setSummaryOff("Izključeno");
        preferenceSpor.setSummaryOn("Vključeno");
        // za checkbox
        //android.preference.CheckBoxPreference preferenceCheck =(android.preference.CheckBoxPreference) findPreference("mute");
        //preferenceCheck.setSummaryOff("Izključeno");
        //preferenceCheck.setSummaryOn("Vključeno");

        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getActivity());
        boolean preveri = sharedPreferences.getBoolean("switch1",false);
        boolean preveri2 = sharedPreferences.getBoolean("switch2",false);
        //boolean preveri3 = sharedPreferences.getBoolean("mute",false);
        if(preveri == true){
            Toast.makeText(getActivity(),"Vibriranje je vključeno ", Toast.LENGTH_SHORT).show();
        }
        else{
            Toast.makeText(getActivity(),"Vibriranje je izključeno ", Toast.LENGTH_SHORT).show();
        }
        if(preveri2 == true){
            Toast.makeText(getActivity(),"Obveščanje je vključeno ", Toast.LENGTH_SHORT).show();
        }
        else{
            Toast.makeText(getActivity(),"Obveščanje je izključeno ", Toast.LENGTH_SHORT).show();
        }
        /*if(preveri3 == true){
            Toast.makeText(getActivity(),"Zvok je vključen ", Toast.LENGTH_SHORT).show();
        }
        else{
            Toast.makeText(getActivity(),"Zvok je izključen ", Toast.LENGTH_SHORT).show();
        }*/
    }


}
